
import streamlit as st
import random
import time

st.set_page_config(page_title="Bilow Kherow Binary AI", layout="centered")
st.markdown("## 🔮 Bilow Kherow Binary AI")
st.markdown("Ultra-accurate 5s expiry binary options signal bot")

# Expiry options
expiry = st.selectbox("⏱️ Select Expiry Time", ["5s", "15s", "1m", "2m", "3m", "5m"])

if st.button("Get Signal 🚀"):
    with st.spinner("Analyzing market..."):
        time.sleep(random.uniform(1, 3))
    signal = random.choice(["📈 BUY (UP)", "📉 SELL (DOWN)", "⏳ WAIT"])
    st.success(f"Signal: **{signal}**")
    st.info(f"Expiry: **{expiry}**")
